# Aiora — Orchestral Factory Presets (Legacy Reference)
Archived from native-android commit 9a4853e85537140fb36bba2081308618729b8fb7 (Beta 0.7.81).
These **19 orchestral presets** are retired from the four-instrument factory bank;
Subula, Spectrello, Nebular and Nexdrum remain active.
This is a reference-only archive, not a current Aiora factory bank.

## Files and restoration
- `patches/*.patch.json` are original patches exported from the historical C++ factory builder using the same serializePatchJson() format Aiora imports. Import each as a normal instrument patch.
- `source/FactoryPresets.cpp` and `source/FactoryPresets.h` are the untouched original builder definitions.
- `source/export_legacy_orchestra.cpp` is the reproducible exporter source.
- The old original source is recoverable with `git show 9a4853e85537140fb36bba2081308618729b8fb7:app/src/main/cpp/FactoryPresets.cpp`.

## Historical model and modern equivalents
Legacy orchestra voicings used six oscillators with per-operator ADSR envelopes, custom 16-partial harmonic banks (zero-filled into the modern 64-partial spectrum), optional alternate harmonics, FM, pitch vibrato, filters and effects. V generally influenced strike intensity/brightness and loudness; M controlled bow pressure, air/embouchure drive, mallet pressure or damping, depending on the patch.
- ADSR and other legacy levels remain encoded in each patch; modern volume and volume-morph curves provide more detailed trajectories if redesigned.
- Legacy Morph1..6 patch-level destinations differ from today's operator waveform-morph routing. Loading may preserve legacy values, but users should inspect morph behavior.
- Filter and FX values are historical authored settings; today's evolving filter and FX rack offer additional controls but are not implied by the originals.
- Orchestral percussion had special legacy membrane/cymbal behaviors where enabled. Newer Nexdrum uses independently authored modern six-operator patches instead.
- No claim is made that archived voicings reproduce original historical output sample-for-sample under the current engine.

## Inventory
Strings: Violin, Viola, Cello, Contrabass.
Woodwinds: Flute, Clarinet, Oboe, Bassoon.
Brass: French Horn, Trumpet, Trombone, Tuba.
Percussion: Timpani, Concert Bass Drum, Concert Snare Drum, Orchestral Cymbals, Tam-Tam Gong, Triangle, Marimba.
